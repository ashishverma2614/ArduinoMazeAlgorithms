/*  Name: Kevin de Haan
    Section: EA1
    Includes code and libraries from Ualberta CS department
*/

#include <Adafruit_GFX.h>    // Core graphics library
#include <Adafruit_ST7735.h> // Hardware-specific library
#include <string.h> // for memcpy
#include <stdlib.h> // for RNG

// standard U of A library settings, assuming Atmel Mega SPI pins
#define SD_CS    5  // Chip select line for SD card
#define TFT_CS   6  // Chip select line for TFT display
#define TFT_DC   7  // Data/command line for TFT
#define TFT_RST  8  // Reset line for TFT (or connect to +5V)

#define JOY_SEL 9 // Joystick select pin, unused as of yet
#define JOY_VERT_ANALOG 0 // Vertical in pin
#define JOY_HORIZ_ANALOG 1 // Horizontal in pin

#define JOY_DEADZONE 128 // Movement threshold
#define JOY_CENTRE 512 // Analog joystick midpoint

#define TFT_WIDTH 128 // Screen dimensions
#define TFT_HEIGHT 160

#define MENU_SPACING 12
#define MAZE_DELAY 20

Adafruit_ST7735 tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_RST);

//int maze[20][20];

int mazeTiles[20][20];
int mazeVertSides[20][19];
int mazeHorizSides[19][20];

typedef struct {
  char mazeType[11]; // null terminated
  char solverType[11];
} menuStruct;

typedef struct {
  int horiz;
  int vert;
  int change;
} moveStruct;

typedef struct {
  int mazeChoice;
  int solverChoice;
} choiceStruct;

menuStruct menuInfo[3];

void fillMenuInfo(){
  char name1[] = "Eller     ";
  char name2[] = "Kruskal   ";
  char name3[] = "Prim      ";
  memcpy(menuInfo[0].mazeType, name1, 11);
  memcpy(menuInfo[1].mazeType, name2, 11);
  memcpy(menuInfo[2].mazeType, name3, 11);

  char name4[] = "Stay Right";
  char name5[] = "Tremaux   ";
  char name6[] = "Deadend   ";
  memcpy(menuInfo[0].solverType, name4, 11);
  memcpy(menuInfo[1].solverType, name5, 11);
  memcpy(menuInfo[2].solverType, name6, 11);

}


void setupScreen(){
  tft.fillScreen(0);

  tft.setTextWrap(false);
  tft.setTextColor(0xFFFF, 0x0000); // white characters on black background

  tft.setCursor(0, 0); // where the characters will be displayed
  tft.print("Maze:");
  tft.setCursor(64, 0); // where the characters will be displayed
  tft.print("Solver:");


  for(int i = 0; i < 3; i++){
    tft.setCursor(0, 14 + (i*MENU_SPACING));
    tft.print(menuInfo[i].mazeType);
    tft.print("\n");
  }

  for(int i = 0; i < 3; i++){
    tft.setCursor(64, 14 + (i*MENU_SPACING));
    tft.print(menuInfo[i].solverType);
    tft.print("\n");
  }

}

moveStruct menuRead(){
  int vert = analogRead(JOY_VERT_ANALOG);
  int horiz = analogRead(JOY_HORIZ_ANALOG);
  moveStruct menuMovement;
  menuMovement.change = 0;
  menuMovement.vert = 0;
  menuMovement.horiz = 0;

  if (abs(vert - JOY_CENTRE) > JOY_DEADZONE) {
    menuMovement.change = 1;
    if((vert - JOY_CENTRE) > 0){
      menuMovement.vert = 1;
    } else {
      menuMovement.vert = -1;
    }
  }
  if (abs(horiz - JOY_CENTRE) > JOY_DEADZONE) {
    menuMovement.change = 1;
    if((horiz - JOY_CENTRE) > 0){
      menuMovement.horiz = 1;
    } else {
      menuMovement.horiz = -1;
    }
  }
  return menuMovement;
}


void switchMenu(int m_new, int m_prev, int n_new, int n_prev){

  if(n_prev == 0){
    tft.setCursor(0, 14+(MENU_SPACING*m_prev));
    tft.setTextColor(0xFFFF, 0x0000); // white characters on black background
    tft.print(menuInfo[m_prev].mazeType);
  } else {
    tft.setCursor(64, 14+(MENU_SPACING*m_prev));
    tft.setTextColor(0xFFFF, 0x0000); // white characters on black background
    tft.print(menuInfo[m_prev].solverType);
  }
  if(n_new == 0){
    //tft.fillRect(0, 14+(MENU_SPACING*m_new), 60, 8, 0x0000);
    tft.setCursor(0, 14+(MENU_SPACING*m_new));
    tft.setTextColor(0x0000, 0xFfFF); // black characters on white background
    tft.print(menuInfo[m_new].mazeType);
  } else {
    //tft.fillRect(64, 14+(MENU_SPACING*m_new), 60, 8, 0x0000);
    tft.setCursor(64, 14+(MENU_SPACING*m_new));
    tft.setTextColor(0x0000, 0xFfFF); // black characters on white background
    tft.print(menuInfo[m_new].solverType);
  }

}

void underScore(int column, int row){
  for(int i = 0; i<3; i++){
    tft.fillRect((0 + 64*column), (22 + MENU_SPACING*i), 60, 2, 0x0000);
  }
  tft.fillRect((0 + 64*column), (22 + MENU_SPACING*row), 60, 2, 0x6FC0);
}

choiceStruct startScreen(){
  setupScreen();
  moveStruct menuMovement;
  choiceStruct menuChoice;
  bool stopLoop = false;
  int m_select, n_select, m_prev, n_prev = 0;
  menuChoice.mazeChoice = -1;
  menuChoice.solverChoice = -1;
  int solverChoice = -1;
  switchMenu(m_select, m_prev, n_select, n_prev);

  while(!stopLoop){
    menuMovement = menuRead();
    if (menuMovement.change == 1){
      m_prev = m_select;
      n_prev = n_select;
      m_select += menuMovement.vert;
      n_select += menuMovement.horiz;
      m_select = constrain(m_select, 0, 2);
      n_select = constrain(n_select, 0, 1);
      switchMenu(m_select, m_prev, n_select, n_prev);
      delay(100);
    }
    if(digitalRead(JOY_SEL) == LOW){
      if(n_select == 0){
        menuChoice.mazeChoice = m_select;
        underScore(0, menuChoice.mazeChoice);
      } else {
        menuChoice.solverChoice = m_select;
        underScore(1, menuChoice.solverChoice);
      }
    }
    if((menuChoice.mazeChoice != -1) && (menuChoice.solverChoice != -1)){
      stopLoop = true;
    }
  }
  delay(500);
  return menuChoice;
}

////////////////////////////////////////////////////////////////// mazes

bool randomBool(){
  return (rand() % 2 == 1);
}


void buildMaze(){
  for(int i = 0; i < 20; i++){
    for(int j = 0; j< 19; j++){
      mazeVertSides[i][j] = 0;
    }
  }
  for(int i = 0; i < 19; i++){
    for(int j = 0; j< 20; j++){
      mazeHorizSides[i][j] = 0;
    }
  }
  for(int i = 0; i < 20; i++){
    for(int j = 0; j< 20; j++){
      mazeTiles[i][j] = -1;
    }
  }
}

void drawOutline(){
  tft.drawRect(4, 4, 121, 121, 0xFFFF);
}

void drawVertEdges(int m, int n){
  if(mazeVertSides[m][n] == 1){
    tft.fillRect(10+(n*6), 4+(m*6), 1, 7, 0xFFFF);
  } else {
    tft.fillRect(10+(n*6), 5+(m*6), 1, 5, 0x0000);
  }
  delay(MAZE_DELAY);
}

void drawHorizEdges(int m, int n){
  if(mazeHorizSides[m][n] == 1){
    tft.fillRect(4+(n*6), 10+(m*6), 7, 1, 0xFFFF);
  } else {
    tft.fillRect(5+(n*6), 10+(m*6), 5, 1, 0x0000);
  }
  delay(MAZE_DELAY);
}

void forceGap(int amount, int row, int set){
  int counter = 0;
  if(amount == 1){
    for(int i = 0; i < 20; i++){
      if(mazeTiles[row][i] == set){
        mazeHorizSides[row][i] = 0;
      }
    }
  } else {
    int gap = (rand() % amount + 1);
    for(int i = 0; i < 20; i++){
      if(mazeTiles[row][i] == set){
        counter += 1;
        if(counter == gap){
          mazeHorizSides[row][i] = 0;
        }
      }
    }
  }

}

// void ellerMaze(){
//   srand(millis()); // get RNG seed
//   buildMaze();
//   drawOutline();
//   int gapMatrix[2][400] = {0};
//   int tileSet = 0;
//
//   // First line
//   for(int i = 0; i < 20; i++){
//     if(mazeTiles[0][i] == -1){
//       mazeTiles[0][i] = tileSet;
//       tileSet += 1;
//     }
//   }
//   for(int i = 0; i < 19; i++){
//     mazeVertSides[0][i] = randomBool();
//     drawVertEdges(0, i);
//     if (mazeVertSides[0][i] == 0){
//       mazeTiles[0][i+1] = mazeTiles[0][i];
//     }
//   }
//   for(int i = 0; i < 20; i++){
//     mazeHorizSides[0][i] = randomBool();
//     drawHorizEdges(0, i);
//   }
//   for(int i = 0; i < 20; i++){
//     gapMatrix[1][mazeTiles[0][i]] += 1;
//     if(mazeHorizSides[0][i] == 0){
//       gapMatrix[0][mazeTiles[0][i]] = 1;
//     }
//   }
//   for(int i = 0; i < 20; i++){
//     if(gapMatrix[0][mazeTiles[0][i]] == 0){
//       forceGap(gapMatrix[1][mazeTiles[0][i]], 0, mazeTiles[0][i]);
//       drawHorizEdges(0, i);
//     }
//   }
//
//   for(int i = 0; i < 20; i++){
//     Serial.print(mazeTiles[0][i]); Serial.print(' ');
//   }
//   Serial.println("\n");
//   for(int i = 0; i < 30; i++){
//     Serial.print(gapMatrix[0][i]); Serial.print(' ');
//     Serial.println(gapMatrix[1][i]);
//   }
//
//   //// middle rows
//   for(int j = 1; j < 19; j++){
//     int gapMatrix[400][2] = {0};
//     for(int i = 0; i < 20; i++){
//       if(mazeHorizSides[j-1][i] == 0){
//         mazeTiles[j][i] = mazeTiles[j-1][i];
//       }
//     }
//     for(int i = 0; i < 20; i++){
//       if(mazeTiles[j][i] == -1){
//         mazeTiles[j][i] = tileSet;
//         tileSet += 1;
//       }
//     }
//     for(int i = 0; i < 19; i++){
//       if(mazeTiles[j][i] != mazeTiles[j][i+1]){
//         mazeVertSides[j][i] = randomBool();
//         drawVertEdges(j, i);
//         if (mazeVertSides[j][i] == 0){
//           mazeTiles[j][i+1] = mazeTiles[j][i];
//         }
//       } else {
//         mazeVertSides[j][i] = 1;
//       }
//
//     }
//     for(int i = 0; i < 20; i++){
//       mazeHorizSides[j][i] = randomBool();
//       drawHorizEdges(j, i);
//     }
//     for(int i = 0; i < 20; i++){
//       gapMatrix[1][mazeTiles[j][i]] += 1;
//       if(mazeHorizSides[j][i] == 0){
//         gapMatrix[0][mazeTiles[j][i]] = 1;
//       }
//     }
//     for(int i = 0; i < 20; i++){
//       if(gapMatrix[0][mazeTiles[j][i]] == 0){
//         forceGap(gapMatrix[1][mazeTiles[j][i]], j, mazeTiles[j][i]);
//         drawHorizEdges(j, i);
//       }
//     }
//
//   }
//
//   for(int i = 0; i < 20; i++){
//     for(int j = 0; j < 20; j++){
//       Serial.print(mazeVertSides[i][j]); Serial.print(' ');
//     }
//     Serial.println();
//     for(int j = 0; j < 20; j++){
//       Serial.print(' '); Serial.print(mazeHorizSides[i][j]);
//     }
//     Serial.println();
//   }
//   while(true){}
//
//   for(int j = 0; j < 20; j++){
//     for(int i = 0l i < 20; i++){
//
//     }
//   }
//
//
//}

void setup(void) {
  init();
  Serial.begin(9600);

  pinMode(JOY_SEL, INPUT);
  digitalWrite(JOY_SEL, HIGH);

  tft.initR(INITR_BLACKTAB);
  tft.fillScreen(ST7735_BLACK);
  fillMenuInfo();

}



int main(){
  setup();
  while(true){
    choiceStruct menuChoice = startScreen();
    tft.fillScreen(ST7735_BLACK);
    switch(menuChoice.mazeChoice){
      case 0 :
        ellerMaze();
      case 1 :
        delay(50);
        //kruskalMaze();
      case 2 :
        delay(50);
        //primMaze();
    }
    // switch(menuChoice.solverChoice){
    //   case 0 :
    //     stayRightSolve();
    //   case 1 :
    //     tremauxSolve();
    //   case 2 :
    //     deadendSolve();
    // }

  }

}

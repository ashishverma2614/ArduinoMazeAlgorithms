/*  Names: Duncan Follis, Kevin de Haan
    Section: EA1
    Includes code and libraries from Ualberta CS department
*/

#include <Adafruit_GFX.h>    // Core graphics library
#include <Adafruit_ST7735.h> // Hardware-specific library
#include <string.h> // for memcpy
#include <stdlib.h> // for RNG

// standard U of A library settings, assuming Atmel Mega SPI pins
#define SD_CS    5  // Chip select line for SD card
#define TFT_CS   6  // Chip select line for TFT display
#define TFT_DC   7  // Data/command line for TFT
#define TFT_RST  8  // Reset line for TFT (or connect to +5V)

#define JOY_SEL 9 // Joystick select pin
#define JOY_VERT_ANALOG 0 // Vertical in pin
#define JOY_HORIZ_ANALOG 1 // Horizontal in pin

#define JOY_DEADZONE 128 // Movement threshold
#define JOY_CENTRE 512 // Analog joystick midpoint

#define TFT_WIDTH 128 // Screen dimensions
#define TFT_HEIGHT 160

#define MENU_SPACING 12
#define MAZE_DELAY 8 // 20 is good

#define MENU_LENGTH 4

Adafruit_ST7735 tft = Adafruit_ST7735(TFT_CS, TFT_DC, TFT_RST);

//int maze[20][20];

int mazeTiles[20][20];
int mazeVertSides[20][19];
int mazeHorizSides[19][20];
int newMazeVertSides[20][21];
int newMazeHorizSides[21][20];


typedef struct{
  int tile;
  int rightWall;
  int downWall;
} mazeStruct;

mazeStruct g_maze[21][21];

typedef struct {
  char mazeType[11]; // null terminated
  char solverType[11];
} menuStruct;

menuStruct menuInfo[MENU_LENGTH];

typedef struct {
  int horiz;
  int vert;
  int change;
} moveStruct;

typedef struct {
  int j;
  int i;
  int step;
  int prevDir;
} mazeLoc;

typedef struct {
  int mazeChoice;
  int solverChoice;
} choiceStruct;



void fillMenuInfo(){
  char name1[] = "Eller     ";
  char name2[] = "Kruskal   ";
  char name3[] = "Prim      ";
  char name4[] = "Same      ";
  memcpy(menuInfo[0].mazeType, name1, 11);
  memcpy(menuInfo[1].mazeType, name2, 11);
  memcpy(menuInfo[2].mazeType, name3, 11);
  memcpy(menuInfo[3].mazeType, name4, 11);

  char name5[] = "Stay Right";
  char name6[] = "Tremaux   ";
  char name7[] = "Deadend   ";
  char name8[] = "Brute     ";
  memcpy(menuInfo[0].solverType, name5, 11);
  memcpy(menuInfo[1].solverType, name6, 11);
  memcpy(menuInfo[2].solverType, name7, 11);
  memcpy(menuInfo[3].solverType, name8, 11);




}

void setupScreen(){
  tft.fillScreen(0);

  tft.setTextWrap(false);
  tft.setTextColor(0xFFFF, 0x0000); // white characters on black background

  tft.setCursor(0, 0); // where the characters will be displayed
  tft.print("Maze:");
  tft.setCursor(64, 0); // where the characters will be displayed
  tft.print("Solver:");


  for(int i = 0; i < MENU_LENGTH; i++){
    tft.setCursor(0, 14 + (i*MENU_SPACING));
    tft.print(menuInfo[i].mazeType);
    tft.print("\n");
  }

  for(int i = 0; i < MENU_LENGTH; i++){
    tft.setCursor(64, 14 + (i*MENU_SPACING));
    tft.print(menuInfo[i].solverType);
    tft.print("\n");
  }

}

moveStruct menuRead(){
  int vert = analogRead(JOY_VERT_ANALOG);
  int horiz = analogRead(JOY_HORIZ_ANALOG);
  moveStruct menuMovement;
  menuMovement.change = 0;
  menuMovement.vert = 0;
  menuMovement.horiz = 0;

  if (abs(vert - JOY_CENTRE) > JOY_DEADZONE) {
    menuMovement.change = 1;
    if((vert - JOY_CENTRE) > 0){
      menuMovement.vert = 1;
    } else {
      menuMovement.vert = -1;
    }
  }
  if (abs(horiz - JOY_CENTRE) > JOY_DEADZONE) {
    menuMovement.change = 1;
    if((horiz - JOY_CENTRE) > 0){
      menuMovement.horiz = 1;
    } else {
      menuMovement.horiz = -1;
    }
  }
  return menuMovement;
}

void switchMenu(int m_new, int m_prev, int n_new, int n_prev){

  if(n_prev == 0){
    tft.setCursor(0, 14+(MENU_SPACING*m_prev));
    tft.setTextColor(0xFFFF, 0x0000); // white characters on black background
    tft.print(menuInfo[m_prev].mazeType);
  } else {
    tft.setCursor(64, 14+(MENU_SPACING*m_prev));
    tft.setTextColor(0xFFFF, 0x0000); // white characters on black background
    tft.print(menuInfo[m_prev].solverType);
  }
  if(n_new == 0){
    //tft.fillRect(0, 14+(MENU_SPACING*m_new), 60, 8, 0x0000);
    tft.setCursor(0, 14+(MENU_SPACING*m_new));
    tft.setTextColor(0x0000, 0xFfFF); // black characters on white background
    tft.print(menuInfo[m_new].mazeType);
  } else {
    //tft.fillRect(64, 14+(MENU_SPACING*m_new), 60, 8, 0x0000);
    tft.setCursor(64, 14+(MENU_SPACING*m_new));
    tft.setTextColor(0x0000, 0xFfFF); // black characters on white background
    tft.print(menuInfo[m_new].solverType);
  }

}

void underScore(int column, int row){
  for(int i = 0; i<MENU_LENGTH; i++){
    tft.fillRect((0 + 64*column), (22 + MENU_SPACING*i), 60, 2, 0x0000);
  }
  tft.fillRect((0 + 64*column), (22 + MENU_SPACING*row), 60, 2, 0x3CC3);
}

choiceStruct startScreen(){
  setupScreen();
  moveStruct menuMovement;
  choiceStruct menuChoice;
  bool stopLoop = false;
  int m_select, n_select, m_prev, n_prev = 0;
  menuChoice.mazeChoice = -1;
  menuChoice.solverChoice = -1;
  int solverChoice = -1;
  switchMenu(m_select, m_prev, n_select, n_prev);

  while(!stopLoop){
    menuMovement = menuRead();
    if (menuMovement.change == 1){
      m_prev = m_select;
      n_prev = n_select;
      m_select += menuMovement.vert;
      n_select += menuMovement.horiz;
      m_select = constrain(m_select, 0, MENU_LENGTH-1);
      n_select = constrain(n_select, 0, 1);
      switchMenu(m_select, m_prev, n_select, n_prev);
      delay(100);
    }
    if(digitalRead(JOY_SEL) == LOW){
      if(n_select == 0){
        menuChoice.mazeChoice = m_select;
        underScore(0, menuChoice.mazeChoice);
      } else {
        menuChoice.solverChoice = m_select;
        underScore(1, menuChoice.solverChoice);
      }
    }
    if((menuChoice.mazeChoice != -1) && (menuChoice.solverChoice != -1)){
      stopLoop = true;
    }
  }
  delay(500);
  return menuChoice;
}

////////////////////////////////////////////////////////////////// mazes


bool randomBool(){
  return (rand() % 2 == 1);
}


void buildMaze(){
  for(int j = 0; j < 21; j++){
    for(int i = 0; i< 21; i++){
      g_maze[j][i].rightWall = 0;
      g_maze[j][i].downWall = 0;
      g_maze[j][i].tile = -1;
    }
  }
}

void drawOutline(){
  tft.drawRect(4, 4, 121, 121, 0xFFFF);
}

//search to replace these
void drawEdges(int j, int i){
  if(g_maze[j][i].rightWall == 1){
    tft.fillRect(4+(i*6), -2+(j*6), 1, 7, 0xFFFF);
  } else {
    tft.fillRect(4+(i*6), -1+(j*6), 1, 5, 0x0000);
  }
  if(g_maze[j][i].downWall == 1){
    tft.fillRect(-2+(i*6), 4+(j*6), 7, 1, 0xFFFF);
  } else {
    tft.fillRect(-1+(i*6), 4+(j*6), 5, 1, 0x0000);
  }
  delay(MAZE_DELAY);
}

//quickly draws a grid //search to replace primFill
void gridFill(){
  for(int i = 0; i < 19; i++){
    tft.fillRect(10+(i*6), 4, 1, 120, 0xFFFF);
  }
  for(int i = 0; i < 19; i++){
    tft.fillRect(4, 10+(i*6), 120, 1, 0xFFFF);
  }
}

// fills walls and sets each tile to have a different value
void buildPrimMaze(){
  for(int j = 0; j < 21; j++){
    for(int i = 0; i< 21; i++){
      g_maze[j][i].rightWall = 1;
      g_maze[j][i].downWall = 1;
      g_maze[j][i].tile = -1;
    }
  }
  for(int j = 1; j < 21; j++){
    for(int i = 1; i< 21; i++){
      g_maze[j][i].tile = (20*(j-1) + i-1);
      //Serial.print(g_maze[j][i].tile); Serial.print(' ');
    }
    //Serial.println();
  }
}

// returns 1 if same tile value
int primCheckDown(int j, int i){
  if(g_maze[j][i].tile == g_maze[j+1][i].tile){
    return 1;
  } else {
    return 0;
  }
}

// returns 1 if same tile value
int primCheckRight(int j, int i){
  if(g_maze[j][i].tile == g_maze[j][i+1].tile){
    return 1;
  } else {
    return 0;
  }
}

int primCheckContinue(int seed){
  for(int j = 1; j < 21; j++){
    for(int i = 1; i < 21; i++){
      if(g_maze[j][i].tile != seed){
        return 1;
      }
    }
  }
  return 0;
}

void primMaze(){
  srand(millis());
  drawOutline();
  gridFill();
  buildPrimMaze();
  int seed = (rand() % 399);
  Serial.print("seed: "); Serial.println(seed);
  while(primCheckContinue(seed)){
    for(int j = 1; j < 21; j++){
      for(int i = 1; i < 21; i++){
        if(g_maze[j][i].tile == seed){
          // ensuring !(0 | 1)
          int up = -1;
          int right = -1;
          int down = -1;
          int left = -1;

          if(j > 1){
            if(g_maze[j][i].tile == seed){
              up = primCheckDown(j-1,i);
            }
          }
          if(j < 20){
            if(g_maze[j][i].tile == seed){
              down = primCheckDown(j,i);
            }
          }
          if(i > 1){
            if(g_maze[j][i].tile == seed){
              left = primCheckRight(j, i-1);
            }
          }
          if(i < 20){
            if(g_maze[j][i].tile == seed){
              right = primCheckRight(j, i);
            }
          }

          if((up == 0) && randomBool()){
            g_maze[j-1][i].downWall = 0;
            g_maze[j-1][i].tile = seed;
            drawEdges(j-1, i);
          }
          if((right == 0) && randomBool()){
            g_maze[j][i].rightWall = 0;
            g_maze[j][i+1].tile = seed;
            drawEdges(j, i);
          }
          if((down == 0) && randomBool()){
            g_maze[j][i].downWall = 0;
            g_maze[j+1][i].tile = seed;
            drawEdges(j, i);
          }
          if((left == 0) && randomBool()){
            g_maze[j][i-1].rightWall = 0;
            g_maze[j][i-1].tile = seed;
            drawEdges(j, i-1);
          }
        }
      }
    }
  }
}

void sameMaze(){
  drawOutline();
  for(int j = 1; j < 21; j++){
    for(int i = 1; i < 21; i++){
      if(g_maze[j][i].rightWall == 1){
        tft.fillRect(4+(i*6), -2+(j*6), 1, 7, 0xFFFF);
      }
      if(g_maze[j][i].downWall == 1){
        tft.fillRect(-2+(i*6), 4+(j*6), 7, 1, 0xFFFF);
      }
    }

  }

}

void setup(void) {
  init();
  Serial.begin(9600);

  pinMode(JOY_SEL, INPUT);
  digitalWrite(JOY_SEL, HIGH);

  tft.initR(INITR_BLACKTAB);
  tft.fillScreen(ST7735_BLACK);
  fillMenuInfo();

}

//sets all tiles of the maze to 0, meaning empty
void emptyMazeTiles(){
  for(int i = 0; i<21; i++){
    for(int j = 0; j<21; j++){
      g_maze[i][j].tile = 0;
    }
  }
}

void markPath(int tileNum){
  for(int j = 1; j < 21; j++){
    for(int i = 1; i < 21; i++){
      if(g_maze[j][i].tile == tileNum){
        tft.fillRect((6*i), (6*j), 3, 3, 0xFFFF);
      }
    }
  }
}


void printMazeLoc(mazeLoc currentLoc){
  int tileR = constrain(abs(currentLoc.step-484)-129, 0, 255);
  int tileG = constrain(-abs(currentLoc.step-612)+255, 0, 255);
  int tileB = constrain(-abs(currentLoc.step-356)+255, 0, 255);
  uint16_t tileColour = tft.Color565(tileR, tileG, tileB);
  tft.fillRect(-1+(6*currentLoc.i), -1+(6*currentLoc.j), 5, 5, tileColour);
  delay(MAZE_DELAY*4);


}

bool checkFinish(mazeLoc currentLoc){
  if((currentLoc.i == 20) && (currentLoc.j == 20)){
    return true;
  } else {
    return false;
  }
}

void fullWallsSetup(){

    for(int j = 1; j < 21; j++){
      g_maze[j][0].rightWall = 1;
    }
    for(int i = 1; i < 21; i++){
      g_maze[0][i].downWall = 1;
    }

}

mazeLoc stayRightCheck(mazeLoc currentLoc){
  int rightGuess = (currentLoc.prevDir+3) % 4;
  while(true){
    if((rightGuess % 4) == 0){
      if(g_maze[currentLoc.j-1][currentLoc.i].downWall == 0){
        currentLoc.prevDir = 2;
        currentLoc.j -= 1;
        currentLoc.step += 1;
        printMazeLoc(currentLoc);
        return currentLoc;
      }
    }
    if((rightGuess % 4) == 1){
      if(g_maze[currentLoc.j][currentLoc.i].rightWall == 0){
        currentLoc.prevDir = 3;
        currentLoc.i += 1;
        currentLoc.step += 1;
        printMazeLoc(currentLoc);
        return currentLoc;
      }
    }
    if((rightGuess % 4) == 2){
      if(g_maze[currentLoc.j][currentLoc.i].downWall == 0){
        currentLoc.prevDir = 0;
        currentLoc.j += 1;
        currentLoc.step += 1;
        printMazeLoc(currentLoc);
        return currentLoc;
      }
    }
    if((rightGuess % 4) == 3){
      if(g_maze[currentLoc.j][currentLoc.i-1].rightWall == 0){
        currentLoc.prevDir = 1;
        currentLoc.i -= 1;
        currentLoc.step += 1;
        printMazeLoc(currentLoc);
        return currentLoc;
      }
    }
    rightGuess = ((rightGuess + 3) % 4); // cycles through possibilities

  }

}

int stayRightSolve(){


  fullWallsSetup();
  emptyMazeTiles();
  mazeLoc currentLoc;
  currentLoc.j = 1;
  currentLoc.i = 1;
  currentLoc.step = 0;
  currentLoc.prevDir = 3;
  printMazeLoc(currentLoc);
  g_maze[currentLoc.j][currentLoc.i].tile = 1;

  mazeLoc prevLoc; // this forces a down-check first
  prevLoc.i = 0;
  prevLoc.j = 1;
  prevLoc.step = 3; // 0 = up 1 = right etc, direction of origin

  while(true){
    currentLoc = stayRightCheck(currentLoc);
    g_maze[currentLoc.j][currentLoc.i].tile = 1;
    if(checkFinish(currentLoc)){
      //markRightPath(1);
      return currentLoc.step;
    }

  }

}


void fillNewWall(int j, int i, int step){
  g_maze[j-1][i].downWall = 1;
  g_maze[j][i].downWall = 1;
  g_maze[j][i-1].rightWall = 1;
  g_maze[j][i].rightWall = 1;
  g_maze[j][i].tile = 1;
  int tileR = constrain(abs(step-484)-129, 0, 255);
  int tileG = constrain(-abs(step-612)+255, 0, 255);
  int tileB = constrain(-abs(step-356)+255, 0, 255);
  uint16_t tileColour = tft.Color565(tileR, tileG, tileB);
  tft.fillRect(-1+(6*i), -1+(6*j), 5, 5, tileColour);
  delay(MAZE_DELAY*4);


}

bool checkDeadEnd(int j, int i){
  int numWalls = 0;
  if(g_maze[j][i].rightWall == 1){
    numWalls++;
  }
  if(g_maze[j-1][i].downWall == 1){
    numWalls++;
  }
  if(g_maze[j][i-1].rightWall == 1){
    numWalls++;
  }
  if(g_maze[j][i].downWall == 1){
    numWalls++;
  }
  if(numWalls == 3){
    return true;
  } else {
    return false;
  }
}

int deadendSolve(){
  int step = 0;
  fullWallsSetup();
  emptyMazeTiles();
  while(true){
    bool keepRunning = false;
    for(int j = 1; j < 21; j++){
      for(int i = 1; i < 21; i++){
        if((g_maze[j][i].tile == 0) && ((j+i != 2) && (j+i != 40))){ // leaves the start and end alone
          if(checkDeadEnd(j, i)){
            fillNewWall(j, i, step);
            step++;
            keepRunning = true;
          }
        }
      }
    }
    if(!keepRunning){
      //markPath(0);
      return step;
    }
  }
}

void mazeMenu(int steps){
  tft.setTextColor(0x0000, 0xFFFF); // black characters on white background
  tft.setCursor(32, 144);
  tft.print("Re-select");
  tft.setTextColor(0xFFFF, 0x0000); // white characters on black background
  tft.setCursor(8, 130);
  tft.print("Steps Taken: "); tft.print(steps);
  while(true){
    if(!digitalRead(JOY_SEL)){
      break;
    }
  }
}


int main(){
  setup();
  while(true){
    int step = 0;
    choiceStruct menuChoice = startScreen();
    tft.fillScreen(ST7735_BLACK);
    switch(menuChoice.mazeChoice){
      case 0 :
        delay(50);
        //ellerMaze();
      case 1 :
        delay(50);
        //kruskalMaze();
      case 2 :
        delay(50);
        primMaze();
        break;
      case 3 :
        delay(50);
        sameMaze();
        break;
    }
    switch(menuChoice.solverChoice){
      case 0 :
        delay(50);
        step = stayRightSolve();
        mazeMenu(step);
        break;
      case 1 :
        delay(50);
        //step = tremauxSolve();
        //mazeMenu(step);
        break;
      case 2 :
        delay(50);
        step = deadendSolve();
        mazeMenu(step);
        break;
    }

    //while(true){};

  }

}
